
//Declaring oneWire Pin
sbit OW_Bit at P1_2_bit;

const unsigned short TEMP_RESOLUTION = 12;

unsigned temp;

void Display_Temperature(unsigned int temp) {
  char ssdAnode[10]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};
  char tempData[5];
  char neg;
  char raw_temperature;
  unsigned int fractionNumber;

  // check for negative number
  if (temp & 0xF800) {
    neg=1;
    temp = ~temp + 1;
  }

 raw_temperature=temp>>4;

  tempData[0]=raw_temperature/100;
  tempData[1]=(raw_temperature/10)%10;
  tempData[2]=raw_temperature%10;

  //process the fraction number
  fractionNumber  = temp;
  fractionNumber &= 0x000F;
  fractionNumber *= 625;

  //process the fraction digits
  tempData[3]=fractionNumber/1000;
  tempData[4]=(fractionNumber%1000)/100;

  P3=0x00;
  if(neg==1) P2=0xBF;
  else P2=ssdAnode[tempData[0]];
  if((raw_temperature>=100)|(neg==1)) P3=0x01;
  Delay_ms(5);
  
  P3=0x00;
  P2=ssdAnode[tempData[1]];
  if(raw_temperature>=10) P3=0x02;
  Delay_ms(5);
  
  P3=0x00;
  P2=ssdAnode[tempData[2]]&0x7F;
  P3=0x04;
  Delay_ms(5);
  
  P3=0x00;
  P2=ssdAnode[tempData[3]];
  P3=0x08;
  Delay_ms(5);
  
  P3=0x00;
  P2=ssdAnode[tempData[4]];
  P3=0x10;
  Delay_ms(5);
}

void readOneWire(){

    // force to reset one wire
    Ow_Reset();
    //skip rom command
    Ow_Write(0xCC);
    //convert the temperature
    Ow_Write(0x44);
    Delay_us(120);
    Ow_Reset();
    //command to skip rom
    Ow_Write(0xCC);
    //read the temperature from RAM
    Ow_Write(0xBE);
    temp =  Ow_Read();
    temp = (Ow_Read() << 8) + temp;
}

void main() {

  while(1) {
    readOneWire();
    //Call the display function
    Display_Temperature(temp);
  }
}